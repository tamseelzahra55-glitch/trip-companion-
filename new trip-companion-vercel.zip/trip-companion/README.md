# Trip Companion · Malaysia × Thailand (v16)

A phone-first trip app for Tamseel + Ayesha. Plain HTML/CSS/JS — no build step — so it deploys to Vercel as a static site and installs on a phone like an app (Add to Home Screen).

## Deploy to Vercel

**Option A — GitHub (easiest to update later)**
1. Create a new GitHub repository and upload everything in this folder (keep `index.html` at the top level).
2. Go to vercel.com → **Add New… → Project** → import that repository.
3. Framework preset: **Other**. Leave Build Command and Output Directory empty. Click **Deploy**.
Every later push to GitHub redeploys automatically.

**Option B — Vercel CLI from your computer**
1. Install Node.js (LTS) if you don’t have it.
2. Open a terminal in this folder and run `npx vercel` — sign in when the browser opens, accept the defaults.
3. The first deploy is already production. For later updates run `npx vercel --prod`.

Then open the URL on your phone → Share → **Add to Home Screen**.

## What’s inside

| Path | What it is |
|---|---|
| `index.html` | App markup (tabs, modals, nav) |
| `css/app.css`, `css/v16.css` | Original styles + v16 additions |
| `js/data-base.js` | Schema, country defaults, key dates, first-timer essentials, phrasebook |
| `js/data-core.js` | The original 5 route cities (generated from v15) + new noob info |
| `js/data-more-my.js` / `js/data-more-th.js` | The 16 added cities |
| `js/features.js` | City browser, editable route, essentials, converter, no-pork filter, journey |
| `js/app.js` | The v15 app logic, with fixes |
| `js/config.js` | Community (Supabase) settings |
| `service-worker.js`, `manifest.webmanifest`, `icons/` | Offline + installable app |
| `vercel.json` | Headers (service-worker caching, security) |

## Editing city info
Each extra city is one `add({...})` block in `js/data-more-*.js`. Rows are short arrays — e.g. a food row is
`['Name', 'BADGE', 'one-line note', 'halal' | 'pork' | '', 'source URL']`.
After editing, bump `VERSION` in `service-worker.js` so phones pick up the change.

## Notes
- Everything personal (plans, spending, journey) is stored only in the phone’s browser. Use **My trip → Backup** before switching phones.
- Weather uses MET Malaysia where available, otherwise Open-Meteo. Exchange rates come from open.er-api.com and are shown as approximate.
- Community needs the Supabase project in `js/config.js` to be live; browsing works without signing in.
